ERNAKULAM HISTORICAL FLOOD MAP DATASET — DRAFT

Source: user-provided Ernakulam_Hist map.pdf (58 pages; KSDMA / RISK LAB, KSEOC labels visible in PDF).

Files:
- map_inventory.csv: detected taluk map pages and return-period titles.
- exposed_hospitals_schools.csv: facility rows from “Return Probability (Historic)” pages, with return-period ticks parsed from PDF text layout. IMPORTANT: tick-column alignment is automatically estimated and must be verified against the PDF before use.
- flood_inundation_metrics_extracted.csv: candidate rows parsed from text tables for inundation area and maximum flood level. Must be verified.
- locality_map_labels_candidates.csv: candidate map label text only. It does NOT assign a locality to a flood hazard class.

Important limitations: this is a preliminary OCR/text extraction, not a validated geospatial dataset. The map's flood shading is graphical and cannot reliably be assigned to individual localities from extracted text alone. No coordinates or point-in-polygon hazard labels were invented. Return periods are scenario labels, not a forecast of when the next flood will occur. Do not train or deploy a real warning model from this alone.

Recommended next step: visually verify extracted table rows and digitize flood polygons from the map pages using QGIS/georeferencing, preserving the source map and its legend. Then join facilities/localities spatially only when coordinates or boundaries are verified.
